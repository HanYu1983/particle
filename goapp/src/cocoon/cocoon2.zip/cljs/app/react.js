// Compiled by ClojureScript 0.0-2268
goog.provide('app.react');
goog.require('cljs.core');
goog.require('cljs.core.async');
goog.require('cljs.core.async');
goog.require('cljs.core.async');
app.react.onTick = cljs.core.async.chan.call(null);
app.react.onImage = cljs.core.async.chan.call(null);
