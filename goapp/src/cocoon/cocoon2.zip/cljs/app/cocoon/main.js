// Compiled by ClojureScript 0.0-2268
goog.provide('app.cocoon.main');
goog.require('cljs.core');
app.cocoon.main.main = (function main(){return alert("cocoon start");
});
app.cocoon.main.main.call(null);
